console.log("Welcome! ");
console.log("How well do you know Piyush! ");
console.log("");

console.log("       Rule: Press any one gave to you in options");
  console.log("");
console.log("             1 Right ans = +10");
console.log("             1 Wrong ans = -10");
console.log("");


//thing that required
var score = 0;
var readlineSync = require("readline-sync");
console.log("");
var playerName = readlineSync.question("What is your name? ");
console.log("Fine, lets play game");
console.log();
 


//funciton
  console.log("Q 1) Where do piyush live at? ");
  console.log("  a) Pune");
  console.log("  b) Hiwarkhed");
  console.log("  c) Amravati");
  console.log("  d) Not from above! ");
  console.log("");
  
  var userInput = readlineSync.question("You choose option : " );
console.log();
  //realans
  var realAns = "b";
  if (realAns === userInput) {
    console.log("        Yeahh, You're Right.");
    console.log();
    score += 10;
  }else{
    console.log("        Wrong! ");
    console.log();
    score;
  }

console.log();


  //2nd que.

  console.log("Q 2) Which is fav actor of Piyush? ");
  console.log("  a) Allu Arjun");
  console.log("  b) Vijay D");
  console.log("  c) Dhanush");
  console.log("d) None of above! ");
  console.log("");
  
  
   userInput = readlineSync.question("You choose option : " );

console.log();
  //realans
  var realAns = "a";
  if (realAns === userInput) {
    console.log("        You're Right.");
    score += 10;
    console.log();
  }else{
    console.log("        Wrong! ");
    score;
    console.log();
  }

console.log();

  //3rd que
  console.log("Q 3) Which is fav actress of Piyush? ");
  console.log("  a) Samantha");
  console.log("  b) Rashmika");
  console.log("  c) a & b");
  console.log("  d) Non of above!");
  console.log("");
  
 userInput = readlineSync.question("You choose option : " );

console.log();

  //realans
  var realAns = "c";
  if (realAns === userInput) {
    console.log("        You're Right.");
    score += 10;
    console.log();
  }else{
    console.log("        Wrong! ");
    console.log();
    score;
  }

console.log();

   //4rth que
  console.log("Q 4) Which is Piyush's fav Dish ? ");
  console.log("  a) Biryani");
  console.log("  b) Bhindi Masala :(");
  console.log("  c) Potato Peas Curry");
  console.log("  d) Idli Sambar ");
  console.log("  e) None of Above!");
  console.log("");
  
   userInput = readlineSync.question("You choose option : " );

console.log();
  //realans
  var realAns = "c";
  if (realAns === userInput) {
    console.log("        Yeahh, You're Right.");
    score += 10;
    console.log();
  }else{
    console.log("        Wrong! ");
    console.log();
    score;
  }

console.log();

   //5th que
  console.log("Q 5) Which is Piyush's fav place ? ");
  console.log("  a) Leh-Ladakh");
  console.log("  b) Dubai");
  console.log("  c) Paris");
  console.log("  d) Home ");
  console.log("  e) None of Above!");
  console.log("");
  
   userInput = readlineSync.question("You choose option : " );


console.log();

  //realans
  var realAns = "d";
  if (realAns === userInput) {
    console.log("         You're Right.");
    score += 10;
    if(score === 50){
        console.log("      Great, You win the Game :)");   
    }
    
    console.log();
  }else{
    console.log("        Wrong! ");
    console.log();
    console.log("Well, I really apprecite you, that you came this far :)");
    console.log();
    score;
  }


  console.log();

  console.log("you're final score is: " +score);
  console.log();
  console.log("Thanks for playing " +playerName+ "....");  
